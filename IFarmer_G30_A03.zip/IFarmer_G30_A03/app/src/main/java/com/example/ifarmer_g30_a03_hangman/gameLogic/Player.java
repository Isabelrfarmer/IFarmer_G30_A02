package com.example.ifarmer_g30_a03_hangman.gameLogic;

import android.content.Context;

import com.example.ifarmer_g30_a03_hangman.linked_data_structures.DoublyLinkedList;
import com.example.ifarmer_g30_a03_hangman.linked_data_structures.SinglyLinkedList;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;


/**
 * <p>Title: Player </p>
 * <p>Description: Player.java contains all logic concerning a player and their games.</p>
 * <p>Course: 420-G30 Programming III</p>
 *
 * @author Isabel Farmer
 */

public class Player implements Serializable {
    private String player;
    private int numGamesPlayed;
    protected int numGamesWon;
    public Dictionary words;
    public String gameWord;
    public int incorrectGuessCount;
    public SinglyLinkedList<String> previousGuesses = new SinglyLinkedList<String>();
    public boolean gotHint;
    private static final long serialVersionUID = 5401935074893086871L;
    protected String currHangmanImg = "";
    public DoublyLinkedList<Player> allPlayers = new DoublyLinkedList<Player>();
    protected String storeGames = "previousPlayers.txt";
    public transient Context context1;

    public Player() {
        setPlayerName("Unknown");
        numGamesPlayed = 0;
        numGamesWon = 0;
        incorrectGuessCount = 6;
        gotHint = false;
    } // Player()

    public Player(String name, Context context) {
        setPlayerName(name);
        numGamesPlayed = 0;
        numGamesWon = 0;
        words = new Dictionary(context);
        incorrectGuessCount = 6;
        context1 = context;
        gotHint = false;
        deserialize();

    } // Player(String)

    public void incrementIncorrectGuessCount() {
        incorrectGuessCount--;
    } // incrementIncorrectGuessCount()

    public void addPlayer(Player player) throws IOException {
        allPlayers.add(player);
        serialize();
    } // addPlayer()

    protected DoublyLinkedList<Player> getAllPlayers() {
        return allPlayers;
    } // getAllPlayers()

    public int getIncorrectGuessCount() {
        return incorrectGuessCount;
    } // getIncorrectGuessCount()

    protected void setPlayerName(String name) {
        player = name;
    } // setPlayerName(String)

    public String getPlayerName() {
        return player;
    } // getPlayerName()

    public void previousGuesses(String letter) {
        previousGuesses.add(letter);
    } // previousGuesses(String)

    protected SinglyLinkedList<String> getPreviousGuesses() {
        return previousGuesses;
    } // getPreviousGuesses()

    public void incrementNumGamesPlayed() {
        numGamesPlayed++;
    } // incrementNumGamesPlayed()

    public int getNumGamesPlayed() {
        return numGamesPlayed;
    } // getNumGamesPlayed()

    protected void incrementNumGamesWon() {
        numGamesWon++;
    } // incrementNumGamesWon()

    public int getNumGamesWon() {
        return numGamesWon;
    } // getNumGamesWon()

    public boolean chooseWord() {
        boolean isValid = true;
        try {
            int max = words.wordsList.getLength() - 1;
            int min = 0;
            int range = max - min + 1;
            int randomNum = (int) (Math.random() * range) + min;
            gameWord = words.wordsList.getElementAt(randomNum);
            words.splitWord(gameWord);
            removeWord(randomNum);
        } catch (IndexOutOfBoundsException e) {
            isValid = false;
        }
        return isValid;

    } // choseWord()

    protected void removeWord(int randomNum) {
        words.wordsList.remove(randomNum);
    } // removeWord(int)

    protected String getWord() {
        return gameWord;
    } // getWord()

    public boolean takeTurn(String x) {
        boolean wordIsFound = false;
        String pAns = String.valueOf(x.charAt(0));
        for (int i = 0; i < gameWord.length(); ++i) {
            char current = gameWord.charAt(i);

            if (pAns.equalsIgnoreCase(String.valueOf(current))) {
                wordIsFound = true;
            }
        }
        return wordIsFound;
    } // takeTurn(String)

    public boolean serialize() throws IOException {
        boolean isSaved = true;
        File file = new File(context1.getFilesDir(), storeGames);
        FileOutputStream fileStream = new FileOutputStream(file);
        ObjectOutputStream out = new ObjectOutputStream(fileStream);

        out.writeObject(allPlayers);
        out.close();
        fileStream.close();


        return isSaved;

    } // serialize()

    public boolean deserialize() {
        boolean isDec = true;
        try {
            File file = new File(context1.getFilesDir(), storeGames);
            FileInputStream fileStream = new FileInputStream(file);
            ObjectInputStream in = new ObjectInputStream(fileStream);


            allPlayers = (DoublyLinkedList<Player>) in.readObject();

            in.close();
            fileStream.close();

        } catch (ClassNotFoundException e) {
            isDec = false;
        } catch (IOException e) {
            isDec = false;
        }
        return isDec;
    } // deserialize()

    public Player getMostRecentPlayer() {
        Player recentP = allPlayers.getElementAt(0);
        return recentP;
    } // getMostRecentPlayer()

    public void setUpNewGame(boolean isWon) {
        incrementNumGamesPlayed();
        incorrectGuessCount = 6;
        gotHint = false;
        previousGuesses = new SinglyLinkedList<String>();
        if (isWon) {
            incrementNumGamesWon();
        }

    } // setUpNewGame(boolean)

    public boolean isPlayerStored(Player player) {
        boolean isPresent = false;
        for (int i = 0; i < allPlayers.getLength() && isPresent == false; i++) {
            Player pListPlayer = allPlayers.getElementAt(i);
            if (player.getPlayerName().equals(pListPlayer.getPlayerName())
                    && player.getNumGamesPlayed() == pListPlayer.getNumGamesPlayed()
                    && player.getNumGamesWon() == pListPlayer.getNumGamesWon()) {
                isPresent = true;
            } // if
        } // for
        return isPresent;
    } // isPlayerStored(Player)

} // player class
