package com.example.ifarmer_g30_a03_android;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class newGame extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_game);
        setUp();

    }

    private void setUp() {
        Bundle extras = getIntent().getExtras();
        String value = extras.getString("pName");
        TextView temp = (TextView) findViewById(R.id.pName);
        temp.setText(value);
    }
}