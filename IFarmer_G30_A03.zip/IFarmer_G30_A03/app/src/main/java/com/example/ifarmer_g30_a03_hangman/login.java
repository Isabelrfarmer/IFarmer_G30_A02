package com.example.ifarmer_g30_a03_hangman;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class login extends AppCompatActivity implements View.OnClickListener {
    Button nameEnterBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        nameEnterBtn = (Button) findViewById(R.id.btnEnterPlayerName);
        nameEnterBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == nameEnterBtn) {
            EditText pNameText = (EditText) findViewById(R.id.inputPlayerName);
            String pName = pNameText.getText().toString();
            checkPlayerName(pName);
        }
    }

    private void checkPlayerName(String pName) {

        if (TextUtils.isEmpty(pName)) {
            Toast.makeText(this, "You did not enter a username", Toast.LENGTH_SHORT).show();
            return;
        } else if (pName.length() > 18) {
            Toast.makeText(this, "Username must be less than 18 characters long", Toast.LENGTH_SHORT).show();
            return;
        } else {

            Intent i = new Intent(login.this, newGame.class);
            i.putExtra("pName", pName);
            i.putExtra("resume", "false");
            startActivity(i);
        }
    }
}