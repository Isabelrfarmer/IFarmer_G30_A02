package com.example.ifarmer_g30_a03_hangman.gameLogic;

import android.content.Context;

import com.example.ifarmer_g30_a03_hangman.linked_data_structures.SinglyLinkedList;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;


/**
 * <p>Title: Dictionary </p>
 * <p>Description: Dictionary.java contains logic to read and validate a file containing words, which stores its data using SinglyLinkedLists.</p>
 * <p>Course: 420-G30 Programming III</p>
 *
 * @author Isabel Farmer
 */

public class Dictionary implements Serializable {
    public String filename = "assets/word_db.txt";
    File myExternalFile = new File("assets/", "word_db.txt");
    private FileWriter output;
    protected SinglyLinkedList<String> wordsList = new SinglyLinkedList<String>();
    protected SinglyLinkedList<String> currentWord = new SinglyLinkedList<String>();

    protected Dictionary(Context context) {

        readFile(context);
    } // Dictionary()

    protected boolean readFile(Context context) {
        boolean isValid = true;

        BufferedReader reader = null;
        try {
            reader = new BufferedReader(
                    new InputStreamReader(context.getAssets().open("word_db.txt"), "UTF-8"));

            String mLine;
            while ((mLine = reader.readLine()) != null) {
                addWord(mLine);

            }
        } catch (IOException e) {
            isValid = false;
        }


        return isValid;
    } // readFile()

    protected boolean wordIsValid(String line) {
        boolean isValid = true;

        if (line.length() > 15 || line.length() < 1) {
            isValid = false;
        }

        for (int i = 0; i < line.length(); i++) {
            if (!Character.isLetter(line.charAt(i)) && isValid) {
                isValid = false;
            }
        }
        return isValid;
    } // wordIsValid()

    protected void addWord(String word) {
        wordsList.add(word);
    } // addWord(String

    protected void splitWord(String word) {
        String wordArr[] = word.split(word);

        clearCurrentWord();

        for (int i = 0; i < word.length(); i++) {
            String letter = String.valueOf(word.charAt(i));
            currentWord.add(letter);
        }

    } // splitWord(String word)

    private void clearCurrentWord() {
        currentWord = new SinglyLinkedList<String>();
    } // clearCurrentWord()

} // class
