package com.example.ifarmer_g30_a03_android;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
//import android.*;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button newGameBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         newGameBtn = (Button) findViewById(R.id.btnNewGame);
        newGameBtn.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if(v == newGameBtn){
            Intent intent = new Intent(MainActivity.this, login.class);
            startActivity(intent);
        }
    }

}