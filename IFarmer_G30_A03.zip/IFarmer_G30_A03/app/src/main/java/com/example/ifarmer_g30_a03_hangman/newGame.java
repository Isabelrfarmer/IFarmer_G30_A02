package com.example.ifarmer_g30_a03_hangman;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import com.example.ifarmer_g30_a03_hangman.gameLogic.Player;
import com.example.ifarmer_g30_a03_hangman.gameLogic.Scoreboard;
import com.example.ifarmer_g30_a03_hangman.linked_data_structures.SinglyLinkedList;

import java.io.IOException;

public class newGame extends AppCompatActivity implements View.OnClickListener,
        AdapterView.OnItemSelectedListener {
    Player player;
    ImageView makeGuess;
    TextView gameWordView;
    EditText playerGuess;
    ImageView hangmanImg;
    protected Boolean resume = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_game);
        setUp(findViewById(android.R.id.content).getRootView());


        Toolbar menu = findViewById(R.id.myToolbar);
        setSupportActionBar(menu);
        hangmanImg = (ImageView) findViewById(R.id.hangmanImg);
        makeGuess = (ImageView) findViewById(R.id.makeGuessBtn);
        makeGuess.setOnClickListener(this);
    }

    private void setUp(View v) {
        Bundle extras = getIntent().getExtras();
        if (extras.getString("resume").equals("true")) {
            Player placeHolder = new Player("temp", v.getContext());
            placeHolder.deserialize();
            if (placeHolder.allPlayers.getLength() > 0) {
                player = placeHolder.getMostRecentPlayer();
                player.context1 = v.getContext();
                setUpResumesGame();
            } else {
                Toast.makeText(this, "There is no recent game to load. Try new game!",
                        Toast.LENGTH_LONG).show();
                Intent intent = new Intent(newGame.this, MainActivity.class);
                startActivity(intent);
            }

        } else {
            String value = extras.getString("pName");
            TextView temp = (TextView) findViewById(R.id.pName);
            temp.setText("Welcome to hangman " + value + "!");


            // set up game
            player = new Player(value, v.getContext());

            if (!player.chooseWord()) {
                Toast.makeText(this, "The " + player.words.filename + " file could not be read.",
                        Toast.LENGTH_LONG).show();
                Intent intent = new Intent(newGame.this, MainActivity.class);
                startActivity(intent);
            } else {
                player.chooseWord();
                player.incrementNumGamesPlayed();
                gameWordView = (TextView) findViewById(R.id.gameWord);
                String word = player.gameWord;

                String replacedWord = "";
                for (int i = 0; i < word.length(); i++) {
                    if (String.valueOf(word.charAt(i)).equals(" ")) {
                        replacedWord += " ";
                        replacedWord += " ";
                        replacedWord += " ";
                        replacedWord += " ";

                    } else {
                        replacedWord += "_ ";
                    }
                }
                gameWordView.setText(replacedWord);


            }

        }


    }

    private void resetGame() {
        updateIncorrectGuessesRemaining(player.getIncorrectGuessCount());
        updateHangmanImage(player.getIncorrectGuessCount());
        String word = player.gameWord;
        String replacedWord = "";
        for (int i = 0; i < word.length(); i++) {
            if (String.valueOf(word.charAt(i)).equals(" ")) {
                replacedWord += " ";
                replacedWord += " ";
                replacedWord += " ";
                replacedWord += " ";

            } else {
                replacedWord += "_ ";
            }
        }
        gameWordView.setText(replacedWord);
    }

    private void setUpResumesGame() {
        hangmanImg = (ImageView) findViewById(R.id.hangmanImg);
        TextView temp = (TextView) findViewById(R.id.pName);
        temp.setText("Welcome to hangman " + player.getPlayerName() + "!");
        updateIncorrectGuessesRemaining(player.getIncorrectGuessCount());
        gameWordView = (TextView) findViewById(R.id.gameWord);
        String word = player.gameWord;
        String replacedWord = "";
        for (int i = 0; i < word.length(); i++) {
            if (String.valueOf(word.charAt(i)).equals(" ")) {
                replacedWord += " ";
                replacedWord += " ";
                replacedWord += " ";
                replacedWord += " ";

            } else {
                replacedWord += "_ ";
            }
        }
        gameWordView.setText(replacedWord);
        player.incorrectGuessCount = 6;
        resume = true;
        SinglyLinkedList<String> tempPrevGuesses = player.previousGuesses;
        player.previousGuesses = new SinglyLinkedList<String>();
        for (int i = 0; i < tempPrevGuesses.getLength(); i++) {
            String pAns = tempPrevGuesses.getElementAt(i);
            makeGuess(pAns);
        }
        resume = false;

    }

    @Override
    public void onClick(View v) {
        if (v == makeGuess) {
            playerGuess = (EditText) findViewById(R.id.playerGuess);
            String guess = playerGuess.getText().toString();
            makeGuess(guess);
        }
    }

    public void makeGuess(String pAns) {
        InputMethodManager imm = (InputMethodManager) this.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(findViewById(android.R.id.content).getWindowToken(), 0);
        if (validate(pAns)) {
            if (player.takeTurn(pAns)) {
                player.previousGuesses(pAns);


                String word = "";
                ;
                for (int i = 0; i < player.gameWord.length(); i++) {


                    if (String.valueOf(player.gameWord.charAt(i)).trim().equalsIgnoreCase(pAns.trim().toLowerCase())) {
                        word += String.valueOf(player.gameWord.charAt(i)).trim();
                    } // if
                    else if (!String.valueOf(player.gameWord.charAt(i)).trim().equalsIgnoreCase(pAns.trim().toLowerCase())) {
                        String currMatch = "";
                        for (int k = 0; k < player.previousGuesses.getLength(); k++) {
                            if (String.valueOf(player.gameWord.charAt(i)).trim().equalsIgnoreCase(player.previousGuesses.getElementAt(k))) {
                                word += String.valueOf(player.gameWord.charAt(i)).trim();
                                currMatch += String.valueOf(player.gameWord.charAt(i)).trim();
                            }

                        }
                        if (currMatch.length() == 0) {
                            word += "_";
                        }
                    }

                } // for

                String replacedWord = "";
                for (int i = 0; i < player.gameWord.length(); i++) {
                    if (String.valueOf(player.gameWord.charAt(i)).equals(" ")) {
                        replacedWord += " ";
                        replacedWord += " ";
                        replacedWord += " ";
                        replacedWord += " ";
                    } else {
                        replacedWord += String.valueOf(word.charAt(i)) + " ";
                    }
                }
                gameWordView.setText(replacedWord);
            } else {
                player.previousGuesses(pAns);
                updateGuessesMade(pAns);
                player.incrementIncorrectGuessCount();
                updateHangmanImage(player.getIncorrectGuessCount());
                updateIncorrectGuessesRemaining(player.getIncorrectGuessCount());
            } // incorrect letter guess

        } else {
            Toast.makeText(this, "Please enter a single letter. Letter must not have already been guessed.",
                    Toast.LENGTH_SHORT).show();
        } // invalid player input

        try {
            playerGuess.setText("");
        } catch (Exception e) {

        }
        if (!isGameOver()) {
            gameIsOver();

        } // if game is over

    }

    private void updateHangmanImage(int incorrectGuessCount) {
        switch (incorrectGuessCount) {
            case 5:

                hangmanImg.setImageResource(R.drawable.hangmanimg1);
                break;
            case 4:
                hangmanImg.setImageResource(R.drawable.hangmanimg2);
                break;
            case 3:
                hangmanImg.setImageResource(R.drawable.hangmanimg3);
                break;
            case 2:
                hangmanImg.setImageResource(R.drawable.hangmanimg4);
                break;
            case 1:
                hangmanImg.setImageResource(R.drawable.hangmanimg5);
                break;
            case 0:
                hangmanImg.setImageResource(R.drawable.hangmanimg6);

        } // switch
    }

    private void gameIsOver() {
        String resultMsg;
        boolean isWon;
        if (player.getIncorrectGuessCount() == 0) {
            resultMsg = "Sorry " + player.getPlayerName() + " you have run out of guesses and lost the game :'( \n The answer was " + player.gameWord + ". \n Would you like to play again?";
            isWon = false;
        } else {
            resultMsg = "Congratulations " + player.getPlayerName() + "!\n You have won, thanks for playing :) \n Would you like to play again?";
            isWon = true;
        }
        showWinLossPage(resultMsg, isWon);
    }

    private void showWinLossPage(String resultMsg, boolean isWon) {

        InputMethodManager imm = (InputMethodManager) this.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(findViewById(android.R.id.content).getWindowToken(), 0);

        LayoutInflater inflater = (LayoutInflater)
                getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = inflater.inflate(R.layout.activity_winloss, null);


        TextView msg = popupView.findViewById(R.id.winLossMessage);
        msg.setText(resultMsg);
        Button newGameBtn = popupView.findViewById(R.id.playAgainBtn);
        Button exitBtn = popupView.findViewById(R.id.exitGameBtn);


        int width = LinearLayout.LayoutParams.MATCH_PARENT;
        int height = LinearLayout.LayoutParams.MATCH_PARENT;
        boolean focusable = true;
        final PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);


        popupWindow.showAtLocation(findViewById(android.R.id.content), Gravity.CENTER, 0, 0);
        newGameBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                player.setUpNewGame(isWon);
                if (!player.chooseWord()) {
                    Toast.makeText(player.context1, "The " + player.words.filename + " file could not be read.",
                            Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(newGame.this, MainActivity.class);
                    startActivity(intent);
                } else {
                    player.chooseWord();
                    resetGame();
                }

                popupWindow.dismiss();
                try {
                    player.serialize();
                } catch (IOException e) {
                    Toast.makeText(player.context1, "Sorry! the game cannot be saved at this time.",
                            Toast.LENGTH_LONG).show();
                }
            }
        });
        exitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    player.serialize();
                } catch (IOException e) {
                    Toast.makeText(player.context1, "Sorry! the game cannot be saved at this time.",
                            Toast.LENGTH_LONG).show();
                }
                ActivityCompat.finishAffinity(newGame.this);

            }
        });

    }

    private boolean isGameOver() {
        boolean isOver = true;
        int correctCount = 0;
        String currGuessedWord = (String) gameWordView.getText();
        boolean isDone = true;
        for (int i = 0; i < currGuessedWord.length() && isDone == true; i++) {


            if (!String.valueOf(currGuessedWord.charAt(i)).equals("_")) {
                correctCount++;

                if (correctCount == currGuessedWord.length()) {
                    isOver = false;
                } // inner if

            }// outer if
            else {
                isOver = true;
            }

        } // for

        if (player.getIncorrectGuessCount() == 0) {

            isOver = false;
        } // if player runs out of incorrect guesses
        return isOver;
    }

    private void updateIncorrectGuessesRemaining(int incorrectGuessCount) {
        TextView guessesRemaining = (TextView) findViewById(R.id.guessRemainMsg);
        String remainingMsgStr = incorrectGuessCount + " guesses remaining";
        guessesRemaining.setText(remainingMsgStr);
    }

    private void updateGuessesMade(String pAns) {
        TextView prevGuesses = (TextView) findViewById(R.id.previousGuesses);

        String prevGuessStr = "";

        for (int i = player.previousGuesses.getLength() - 1; i >= 0; i--) {
            if (!player.takeTurn(player.previousGuesses.getElementAt(i))) {
                if (prevGuessStr == "") {
                    prevGuessStr += player.previousGuesses.getElementAt(i);
                } else {
                    prevGuessStr += ", " + player.previousGuesses.getElementAt(i);
                }
            }
        } // for

        prevGuesses.setText(prevGuessStr);


    } // updateGuessesMade

    private boolean validate(String pAns) {
        boolean isValid = true;
        if (!resume) {
            if (TextUtils.isEmpty(pAns)) {
                isValid = false;
            }
        }

        if (pAns.length() > 1) {
            isValid = false;
        }

        if (!resume) {
            for (int i = 0; i < player.previousGuesses.getLength(); i++) {
                if (pAns.equals(player.previousGuesses.getElementAt(i))) {
                    isValid = false;
                }
            } // for
        }

        if (!resume) {
            if (isValid) {
                if (!Character.isLetter(pAns.charAt(0))) {
                    isValid = false;
                } // check if pAns is anything other than a alphabetical letter
            }
        }

        return isValid;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.my_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.rules:
                showRules(findViewById(android.R.id.content).getRootView());
                break;
            case R.id.hint:
                getHint();
                break;
            case R.id.scoreboard:
                showScoreBoard(findViewById(android.R.id.content).getRootView());
                break;
            case R.id.resumeGame:
                resumeGame(findViewById(android.R.id.content).getRootView());
                break;
            case R.id.newGame:
                startActivity(new Intent(this, login.class));
                break;

            case R.id.save:
                try {
                    if (!player.isPlayerStored(player)) {
                        player.addPlayer(player);
                    }

                } catch (IOException e) {
                    Toast.makeText(player.context1, "Sorry! the game cannot be saved at this time.",
                            Toast.LENGTH_LONG).show();
                }
                try {
                    player.serialize();
                    Toast.makeText(player.context1, "Game saved!",
                            Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    Toast.makeText(player.context1, "Sorry! the game cannot be saved at this time.",
                            Toast.LENGTH_LONG).show();
                }
                break;
            case R.id.exit:
                this.finishAffinity();
                System.exit(1);
                try {
                    if (!player.isPlayerStored(player)) {
                        player.addPlayer(player);
                    }

                } catch (IOException e) {
                    Toast.makeText(player.context1, "Sorry! the game cannot be saved at this time.",
                            Toast.LENGTH_LONG).show();
                }
                try {
                    player.serialize();
                } catch (IOException e) {
                    Toast.makeText(player.context1, "Sorry! the game cannot be saved at this time.",
                            Toast.LENGTH_LONG).show();
                }
                return (true);
        }

        return (super.onOptionsItemSelected(item));
    }

    String players[];
    PopupWindow resumePopupWindow;

    private void resumeGame(View v) {
        LayoutInflater inflater = (LayoutInflater)
                getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = inflater.inflate(R.layout.activity_resumegame, null);


        players
                = new String[player.allPlayers.getLength() + 1];
        players[0] = "Select";
        for (int i = 1; i < player.allPlayers.getLength() + 1; i++) {
            Player p = (Player) player.allPlayers.getElementAt(i - 1);
            players[i] = p.getPlayerName();
        }

        Spinner spinMenu = popupView.findViewById(R.id.selectGameResume);
        spinMenu.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);
        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, players);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Setting the ArrayAdapter data on the Spinner
        spinMenu.setAdapter(aa);


        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
        boolean focusable = true;
        resumePopupWindow = new PopupWindow(popupView, width, height, focusable);


        resumePopupWindow.showAtLocation(v, Gravity.CENTER, 0, 0);

        popupView.setOnTouchListener((v1, event) -> {
            resumePopupWindow.dismiss();
            return true;
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        try {
            player.serialize();
        } catch (IOException e) {
            Toast.makeText(player.context1, "Sorry! the game cannot be saved at this time.",
                    Toast.LENGTH_LONG).show();
        }
        if (!players[i].equals("Select")) {
            View v = findViewById(android.R.id.content).getRootView();
            Player placeHolder = new Player("temp", v.getContext());
            placeHolder.deserialize();


            player = placeHolder.allPlayers.getElementAt(i - 1);
            player.context1 = v.getContext();

            setUpResumesGame();
            resumePopupWindow.dismiss();
        }
    }


    @SuppressLint("MissingInflatedId")
    private void showScoreBoard(View v) {
        LayoutInflater inflater = (LayoutInflater)
                getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = inflater.inflate(R.layout.activity_scoreboard, null);

        Scoreboard scoreboard = new Scoreboard(player.allPlayers);
        scoreboard.orderPlayers();


        String players[]
                = new String[player.allPlayers.getLength() + 1];
        players[0] = String.format("%-18s%-15s%-10s", "Name", "Games played", "Wins");
        for (int i = 1; i < player.allPlayers.getLength() + 1; i++) {
            Player p = (Player) scoreboard.players.getElementAt(i - 1);
            players[i] = String.format("%-20s%-20s%-20s", p.getPlayerName(),
                    p.getNumGamesPlayed(), p.getNumGamesWon());
        }

        ListView l = popupView.findViewById(R.id.list);
        ArrayAdapter<String> arr;
        arr
                = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_spinner_item,
                players);
        l.setAdapter(arr);


        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
        boolean focusable = true;
        final PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);


        popupWindow.showAtLocation(v, Gravity.CENTER, 0, 0);

        popupView.setOnTouchListener((v1, event) -> {
            popupWindow.dismiss();
            return true;
        });
    }

    private void showRules(View v) {
        LayoutInflater inflater = (LayoutInflater)
                getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = inflater.inflate(R.layout.activity_rules, null);


        int width = LinearLayout.LayoutParams.MATCH_PARENT;
        int height = LinearLayout.LayoutParams.MATCH_PARENT;
        boolean focusable = true;
        final PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);


        popupWindow.showAtLocation(v, Gravity.CENTER, 0, 0);


        popupView.setOnTouchListener((v1, event) -> {
            popupWindow.dismiss();
            return true;
        });
    }


    private void getHint() {
        if (!player.gotHint) {

            boolean hintLetterFound = false;
            String hintLetter;


            for (int k = 0; k < gameWordView.getText().length() && !hintLetterFound; k++) {
                String curLetter = String.valueOf(gameWordView.getText().charAt(k));
                if (curLetter.equals("_")) {
                    String guessLetter = "";
                    if (k == 0) {
                        guessLetter = String.valueOf(player.gameWord.charAt(k));
                    } else {
                        int test = k - (k / 2);
                        guessLetter = String.valueOf(player.gameWord.charAt(test));
                    }

                    makeGuess(guessLetter);
                    hintLetterFound = true;
                }
            }

            player.gotHint = true;
        } // if
        else {
            Toast.makeText(this, "Your hint has already been used.",
                    Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
