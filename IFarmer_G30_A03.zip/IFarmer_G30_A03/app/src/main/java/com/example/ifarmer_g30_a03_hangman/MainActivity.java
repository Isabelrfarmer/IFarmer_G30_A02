package com.example.ifarmer_g30_a03_hangman;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
//import android.*;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button newGameBtn;
    Button resumeGameBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        newGameBtn = (Button) findViewById(R.id.btnNewGame);
        newGameBtn.setOnClickListener(this);

        resumeGameBtn = (Button) findViewById(R.id.btnResumeGame);
        resumeGameBtn.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if (v == newGameBtn) {
            Intent intent = new Intent(MainActivity.this, login.class);
            startActivity(intent);
        } else if (v == resumeGameBtn) {
            Intent intent = new Intent(MainActivity.this, newGame.class);
            intent.putExtra("resume", "true");
            startActivity(intent);
        }
    }

}